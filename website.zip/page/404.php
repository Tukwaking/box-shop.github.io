<?php

    print_r(json_encode([
        "code" => 404,
        "message" => "NOT_FOUND_PAGE", 
    ]));
    exit();